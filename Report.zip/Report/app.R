#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)
library(ggplot2)
library(ozmaps)
library(sf)
library(tidyverse)
library(dplyr)

# state migration data
state_data <- read_csv("States.csv")

# state_map_data
state_shp<- ozmap_data("states")

state_map_data <- dplyr::inner_join(state_data,state_shp,
                                    by = c("States" = "NAME"))

ocp_data <- read.csv("occupation.csv")
ocp_sum <- ocp_data %>% 
  group_by(Occupations) %>%
  summarise(num = n()) %>%
  arrange(desc(num))

gender_data <- read_csv("ooo.csv")

# Define UI for application that draws a histogram
ui <- tagList(
  tags$head(
    HTML("<link rel='stylesheet' type='text/css' href='css/introjs.min.css'>")
  ),
  navbarPage("Australia Migration",
             
             tabPanel(id = "wTab", "Welcome",
                      HTML("<h1 data-step='0' data-intro='This is a tooltip!'>Welcome to Australia Migration Stactics!</h1>",
                           "<h4> The website provides visualizations on Au migration status.</h4>",
                           "<p> </p>",
                           "<p>For the year ending 30 June 2020, there are more than 7.6 million immigrants living in Australia.</p>",
                           "Due to net overseas migration, Australia's population has increased by 194,400. (Migration Australia, 2021)",
                           "<p> </p>",
                           "<img src = 'welcome.png',height = 300, width = 600></img>"),
             
                      HTML("<script type='text/javascript' src='js/intro.min.js'></script>"),
                      HTML("<script type='text/javascript'>document.getElementById('startButton').onclick = function() {
         introJs().setOption('doneLabel', 'Next page').start().oncomplete(function() {
         window.location.hash = '#!tt?multipage=true';
         });
         };</script>")
             ),
             
             tabPanel(id = "fTab", "Mapping",
                      HTML("<h1 data-step='1' data-intro='This is a tooltip!'>Migration Mapping</h1>",
                           "<h4> The mapping data is from 2011 to 2020, presents migration data from all states or territories.</h4>"),
                      sliderInput("year_selected",
                                  "Year",
                                  min = 2011,
                                  max = 2020,
                                  value = 2011
                      ),
                      
                      plotOutput("distPlot"),
                      HTML("<script type='text/javascript' src='js/intro.min.js'></script>"),
                      HTML("<script type='text/javascript'>document.getElementById('startButton').onclick = function() {
         introJs().setOption('doneLabel', 'Next page').start().oncomplete(function() {
         window.location.hash = '#!tt?multipage=true';
         });
         };</script>")
             ),
             
             tabPanel(tabName = "sTab", "Occupations", id = "tt", 
                      HTML("<h1 data-step='2' data-intro='This is a second tooltip!'>Migration Occupations</h1>",
                           "<h4> Top 10 nominated occupations - skill independent Visa.</h4>"),
                      
                      checkboxGroupInput("Occupations", "Occupations: ", 
                                         choices = ocp_sum$Occupations,selected="Total",inline=TRUE),
                      plotOutput("distPlot2"),
  HTML("<script type='text/javascript' src='js/intro.min.js'></script>"),
  HTML("<script type='text/javascript'>document.getElementById('startButton').onclick = function() {
         introJs().setOption('doneLabel', 'Next page').start().oncomplete(function() {
         window.location.hash = '#!tt?multipage=true';
         });
         };</script>")  
),

  tabPanel(tabName = "tTab", "Gender", id = "ttt", 
           HTML("<h1 data-step='3' data-intro='This is a third tooltip!'>Migration Gender</h1>",
                "<h4> Gender data Overseas/Internal.</h4>"),
           
           radioButtons("Gender", "Location: ", 
                              choices = c("Overseas","Internal","Total"),selected="Total",inline=TRUE),
           plotOutput("distPlot3"),
          HTML("<script type='text/javascript' src='js/intro.min.js'></script>"),
          HTML("<script type='text/javascript'>document.getElementById('startButton').onclick = function() {
         introJs().setOption('doneLabel', 'Next page').start().oncomplete(function() {
         window.location.hash = '#!tt?multipage=true';
         });
         };</script>")),

  tabPanel(id = "cTab", "Conclusion",
         HTML("<h1 data-step='4' data-intro='This is a tooltip!'>Conclusion</h1>",
              "<img src = 'map.png'></img>",
              "<p>Regarding the impact of the epidemic on all immigrants, the report gives an analysis from
                three perspectives and concluded that the epidemic has a significant negative impact on skilled 
              individual immigration, but it has a different effect on stateterritory nominated visas. 
              As for migrants from different countries, countries with a large immigration base are greatly affected, 
              and there is a clear trend of reduction, while for other countries with a small base, there is almost 
              no obvious impact. Similarly, states with a large migration base are severely affected by the epidemic, 
              while other states have no negative impact.</p>"),
         
         HTML("<script type='text/javascript' src='js/intro.min.js'></script>"),
         HTML("<script type='text/javascript'>document.getElementById('startButton').onclick = function() {
         introJs().setOption('doneLabel', 'Next page').start().oncomplete(function() {
         window.location.hash = '#!tt?multipage=true';
         });
         };</script>")
)
))

# Define server logic required to draw a histogram
server <- function(input, output) {
  
  # first plot
  output$distPlot <- renderPlot({
    if(input$year_selected == 2011){
      p1 <- ggplot(data=state_map_data,aes(fill=`2011`,geometry=`geometry`))+geom_sf()
    }
    else if (input$year_selected == 2012){
      p1 <- ggplot(data=state_map_data,aes(fill=`2012`,geometry=`geometry`))+geom_sf()
    }
    else if (input$year_selected == 2013){
      p1 <- ggplot(data=state_map_data,aes(fill=`2013`,geometry=`geometry`))+geom_sf()
    }
    else if (input$year_selected == 2014){
      p1 <- ggplot(data=state_map_data,aes(fill=`2014`,geometry=`geometry`))+geom_sf()
    }
    else if (input$year_selected == 2015){
      p1 <- ggplot(data=state_map_data,aes(fill=`2015`,geometry=`geometry`))+geom_sf()
    }
    else if (input$year_selected == 2016){
      p1 <- ggplot(data=state_map_data,aes(fill=`2016`,geometry=`geometry`))+geom_sf()
    }
    else if (input$year_selected == 2017){
      p1 <- ggplot(data=state_map_data,aes(fill=`2017`,geometry=`geometry`))+geom_sf()
    }
    else if (input$year_selected == 2018){
      p1 <- ggplot(data=state_map_data,aes(fill=`2018`,geometry=`geometry`))+geom_sf()
    }
    else if (input$year_selected == 2019){
      p1 <- ggplot(data=state_map_data,aes(fill=`2019`,geometry=`geometry`))+geom_sf()
    }
    
    p1
  })
  
  # second plot
  checkbox <- reactive({
    if (is.null(input$Occupations))
      ocp_data = ocp_data
    else
      ocp_data[ocp_data$Occupations %in% input$Occupations,]
  })
  
  output$distPlot2 <- renderPlot({
    ggplot(data=checkbox(), mapping=aes(x=Year,y=Number,color=Occupations))+
      geom_line()+
      scale_x_continuous(breaks=seq(2011, 2020, 1))+
      geom_text(aes(label=Number), vjust=1.6, color="black", size=2.5)
  })
  
  # third plot

  output$distPlot3 <- renderPlot({
    if (input$Gender == "Total")
      gender_data<- gender_data[gender_data$Gender %in% c("Female","Male"),]
    else if (input$Gender == "Overseas")
      gender_data<- gender_data[gender_data$Gender %in% c("Female_Overseas","Male_Overseas"),]
      else
        gender_data<- gender_data[gender_data$Gender %in% c("Female_Internal","Male_Internal"),]
      
    brks <- seq(-80000, 80000, 10000)
    lbls = paste0(as.character(c(seq(80000, 0, -10000), seq(10000, 80000, 10000))))
    
    p3 <- ggplot(gender_data, aes(x = Year, y = Number, fill = Gender)) +   # Fill column
      geom_bar(stat = "identity", width = .6) +   # draw the bars
      labs(title="Migration Gender") +
      scale_x_continuous(breaks=seq(2011, 2019, 1))+
      scale_y_continuous(breaks=brks,labels = lbls)+
      coord_flip() + 
      theme(plot.title = element_text(hjust = .5), 
            axis.ticks = element_blank()) +   # Centre plot title
      scale_fill_brewer(palette = "Dark2")  # Color palette
    p3
    
  })
    
   
  }

# Run the application 
shinyApp(ui = ui, server = server)
